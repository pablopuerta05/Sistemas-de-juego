using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class PlayerStats : MonoBehaviour
{
    private CharacterScriptableObject characterData;

    // current stats
    private float currentHealth;
    private float currentRecovery;
    private float currentMoveSpeed;
    private float currentMight;
    private float currentProjectileSpeed;
    private float currentMagnet;

    #region Current Stats Properties
    public float CurrentHealth
    {
        get { return currentHealth; }
        set { UpdateStat(ref currentHealth, value, UIManager.Instance.currentHealthDisplay, "Health"); }
    }

    public float CurrentRecovery
    {
        get { return currentRecovery; }
        set { UpdateStat(ref currentRecovery, value, UIManager.Instance.currentRecoveryDisplay, "Health"); }
    }

    public float CurrentMoveSpeed
    {
        get { return currentMoveSpeed; }
        set { UpdateStat(ref currentMoveSpeed, value, UIManager.Instance.currentMoveSpeedDisplay, "Health"); }
    }

    public float CurrentMight
    {
        get { return currentMight; }
        set { UpdateStat(ref currentMight, value, UIManager.Instance.currentMightDisplay, "Health"); }
    }

    public float CurrentProjectileSpeed
    {
        get { return currentProjectileSpeed; }
        set { UpdateStat(ref currentProjectileSpeed, value, UIManager.Instance.currentProjectileSpeedDisplay, "Health"); }
    }

    public float CurrentMagnet
    {
        get { return currentMagnet; }
        set { UpdateStat(ref currentMagnet, value, UIManager.Instance.currentMagnetDisplay, "Health"); }
    }

    #endregion

    // class for defining a level range and the corresponding experience cap increase for that range
    [System.Serializable]
    public class LevelRange
    {
        public int startLevel;
        public int endLevel;
        public int experienceCapIncrease;
    }

    PlayerInventory playerInventory;
    public int weaponIndex;
    public int passiveItemIndex;

    [Header("UI")]
    public Image healthBar;
    public Image expBar;
    public TextMeshProUGUI levelText;

    private void Awake()
    {
        characterData = CharacterSelector.GetData();

        if (characterData == null)
        {
            Debug.LogError("Character data not found!");
            return;
        }

        CharacterSelector.instance.DestroySingleton();

        // assign the variables
        CurrentHealth = characterData.MaxHealth;
        CurrentRecovery = characterData.Recovery;
        CurrentMoveSpeed = characterData.MoveSpeed;
        CurrentMight = characterData.Might;
        CurrentProjectileSpeed = characterData.ProjectileSpeed;
        CurrentMagnet = characterData.Magnet;

        // spawn the starting weapon
        playerInventory.SpawnWeapon(characterData.StartingWeapon);
    }

    private void Start()
    {
        // set the current stats display
        UIManager.Instance.currentHealthDisplay.text = "Health: " + currentHealth;
        UIManager.Instance.currentRecoveryDisplay.text = "Recovery: " + currentRecovery;
        UIManager.Instance.currentMoveSpeedDisplay.text = "Move Speed: " + currentMoveSpeed;
        UIManager.Instance.currentMightDisplay.text = "Might: " + currentMight;
        UIManager.Instance.currentProjectileSpeedDisplay.text = "Projectile Speed: " + currentProjectileSpeed;
        UIManager.Instance.currentMagnetDisplay.text = "Magnet: " + currentMagnet;

        //UIManager.Instance.AssignChosenCharacterUI(characterData);
    }

    private void UpdateStat(ref float stat, float newValue, TextMeshProUGUI display, string statName)
    {
        if (stat != newValue)
        {
            stat = newValue;
            if (GameManager.Instance != null && display != null)
            {
                display.text = $"{statName}: {stat}";
            }
        }
    }
}
