public interface ICollectible
{
    void Collect();
}
